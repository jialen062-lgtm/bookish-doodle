package com.niejiale.zonetask;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ZoneTaskMod.MODID);

    /** 外观：models/item/zone_divider.json 直接引用 minecraft:item/stick 贴图 */
    public static final RegistryObject<Item> ZONE_DIVIDER =
            ITEMS.register("zone_divider", () -> new Item(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
