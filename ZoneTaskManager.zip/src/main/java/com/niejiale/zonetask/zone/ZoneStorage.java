package com.niejiale.zonetask.zone;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * 区域持久化：{世界文件夹}/zonetaskmanager/{命名空间}__{维度路径}.json，每个维度一个文件。
 */
public final class ZoneStorage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<ResourceLocation, Map<String, Zone>> DATA = new HashMap<>();
    private static MinecraftServer server;

    private static class FileData {
        String dimension;
        List<Zone> zones = new ArrayList<>();
    }

    public static void onServerStart(MinecraftServer s) { server = s; DATA.clear(); }
    public static void onServerStop() { server = null; DATA.clear(); }

    private static Path file(ResourceLocation dim) {
        Path dir = server.getWorldPath(LevelResource.ROOT).resolve("zonetaskmanager");
        return dir.resolve(dim.getNamespace() + "__" + dim.getPath().replace('/', '_') + ".json");
    }

    public static synchronized Map<String, Zone> zones(ResourceLocation dim) {
        return DATA.computeIfAbsent(dim, ZoneStorage::load);
    }

    private static Map<String, Zone> load(ResourceLocation dim) {
        Map<String, Zone> map = new LinkedHashMap<>();
        Path p = file(dim);
        if (!Files.exists(p)) return map;
        try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            FileData d = GSON.fromJson(r, FileData.class);
            if (d != null && d.zones != null) for (Zone z : d.zones) if (z != null && z.name != null) map.put(z.name, z);
        } catch (Exception e) {
            System.err.println("[ZoneTaskManager] 读取区域文件失败: " + p + " -> " + e);
        }
        return map;
    }

    private static void save(ResourceLocation dim) {
        Path p = file(dim);
        FileData d = new FileData();
        d.dimension = dim.toString();
        d.zones.addAll(zones(dim).values());
        try {
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p, StandardCharsets.UTF_8)) { GSON.toJson(d, w); }
        } catch (IOException e) {
            System.err.println("[ZoneTaskManager] 保存区域文件失败: " + p + " -> " + e);
        }
    }

    public static synchronized void put(ResourceLocation dim, Zone zone) {
        zones(dim).put(zone.name, zone);
        save(dim);
    }

    public static synchronized boolean remove(ResourceLocation dim, String name) {
        boolean ok = zones(dim).remove(name) != null;
        if (ok) save(dim);
        return ok;
    }

    private ZoneStorage() {}
}
