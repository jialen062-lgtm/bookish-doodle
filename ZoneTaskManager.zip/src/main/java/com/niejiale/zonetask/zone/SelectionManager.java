package com.niejiale.zonetask.zone;

import com.niejiale.zonetask.network.SyncSelectionPacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 服务端：每个玩家当前的 A/B 选点（内存即可，不持久化）。 */
public final class SelectionManager {
    public static final class Sel {
        public final ResourceLocation dim;
        public BlockPos a, b;
        Sel(ResourceLocation dim) { this.dim = dim; }
    }

    private static final Map<UUID, Sel> MAP = new HashMap<>();

    public static Sel get(UUID id) { return MAP.get(id); }
    public static void remove(UUID id) { MAP.remove(id); }
    public static void clear() { MAP.clear(); }

    public static void set(ServerPlayer p, boolean isA, BlockPos pos) {
        ResourceLocation dim = p.level().dimension().location();
        Sel s = MAP.get(p.getUUID());
        if (s == null || !s.dim.equals(dim)) { s = new Sel(dim); MAP.put(p.getUUID(), s); }
        if (isA) s.a = pos.immutable(); else s.b = pos.immutable();
        send(p);
    }

    public static void send(ServerPlayer p) {
        Sel s = MAP.get(p.getUUID());
        SyncSelectionPacket pkt = s == null
                ? new SyncSelectionPacket(p.level().dimension().location(), null, null)
                : new SyncSelectionPacket(s.dim, s.a, s.b);
        ZoneNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }

    private SelectionManager() {}
}
