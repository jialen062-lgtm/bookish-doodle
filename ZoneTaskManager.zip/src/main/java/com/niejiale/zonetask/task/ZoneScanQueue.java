package com.niejiale.zonetask.task;

import com.mojang.logging.LogUtils;
import com.niejiale.zonetask.config.ZoneConfig;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import noppes.npcs.entity.EntityNPCInterface;
import org.slf4j.Logger;

import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * 延迟合并扫描 + 已交战区域周期兜底扫描：
 * 1. 嫌疑人死亡/销毁时把区域标记为“待扫描”，等 DELAY_TICKS 个 tick 后统一扫一次。
 * 2. 记录“已出现过存活嫌疑人”的区域（ENGAGED），每秒兜底复查一次，
 *    防止最后一个 NPC 被击退至边界外死亡、走出区域或死亡事件被其他模组拦截时漏触发撤离。
 */
public final class ZoneScanQueue {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int DELAY_TICKS = 5;   // 0.25 秒，玩家几乎无感
    private static final int FALLBACK_INTERVAL_TICKS = 20;   // 1 秒兜底复查一次

    private static final Map<Zone, ServerLevel> PENDING = new LinkedHashMap<>();
    private static final Map<Zone, ServerLevel> ENGAGED = new IdentityHashMap<>();
    private static int cooldown = 0;
    private static int fallbackCooldown = FALLBACK_INTERVAL_TICKS;

    public static void mark(ServerLevel level, Zone zone) {
        if (PENDING.isEmpty()) cooldown = DELAY_TICKS;
        PENDING.put(zone, level);
        ENGAGED.put(zone, level);
    }

    public static void markEngagedInDimension(ServerLevel level) {
        for (Map.Entry<Zone, ServerLevel> en : ENGAGED.entrySet()) {
            if (en.getValue() == level) {
                mark(level, en.getKey());
            }
        }
    }

    public static void unengageContaining(ServerLevel level, EntityNPCInterface npc) {
        Iterator<Map.Entry<Zone, ServerLevel>> it = ENGAGED.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Zone, ServerLevel> en = it.next();
            if (en.getValue() == level && en.getKey().containsEntity(npc)) {
                it.remove();
            }
        }
    }

    /** 每个服务端 tick 结束时调用 */
    public static void onServerTick(MinecraftServer server) {
        if (EvacuationManager.isActive()) {
            clear();
            return;
        }

        if (!PENDING.isEmpty() && --cooldown <= 0) {
            Map<Zone, ServerLevel> batch = new LinkedHashMap<>(PENDING);
            PENDING.clear();

            Map<ServerLevel, SuspectChecker.Session> sessions = new IdentityHashMap<>();   // 同批共享阵营缓存
            for (Map.Entry<Zone, ServerLevel> en : batch.entrySet()) {
                Zone zone = en.getKey();
                ServerLevel level = en.getValue();
                // 区域在等待期间被删除/覆盖则跳过
                if (ZoneStorage.zones(level.dimension().location()).get(zone.name) != zone) {
                    ENGAGED.remove(zone);
                    continue;
                }
                SuspectChecker.Session s = sessions.computeIfAbsent(level, SuspectChecker.Session::new);
                boolean alive = SuspectChecker.hasAliveSuspect(level, zone, null, s);
                if (ZoneConfig.DEBUG.get()) {
                    LOGGER.info("[ZoneTaskManager] 扫描区域「{}」：{}", zone.name,
                            alive ? "仍有存活嫌疑人 -> " + s.blocker : "已无存活嫌疑人，触发撤离");
                }
                if (!alive) {
                    clear();
                    EvacuationManager.start(level.getServer(), zone);
                    return;
                }
                ENGAGED.put(zone, level);
            }
        }

        if (server == null || --fallbackCooldown > 0) return;
        fallbackCooldown = FALLBACK_INTERVAL_TICKS;

        Set<ServerLevel> activeLevels = new LinkedHashSet<>();
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            activeLevels.add(sp.serverLevel());
        }
        if (activeLevels.isEmpty()) return;

        // 清理已被删除/覆盖的已交战区域
        ENGAGED.entrySet().removeIf(en ->
                ZoneStorage.zones(en.getValue().dimension().location()).get(en.getKey().name) != en.getKey());

        Map<ServerLevel, SuspectChecker.Session> sessions = new IdentityHashMap<>();
        for (ServerLevel level : activeLevels) {
            Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
            if (zones.isEmpty()) continue;
            for (Zone zone : zones.values()) {
                if (!isZoneLoaded(level, zone)) continue;
                boolean wasEngaged = ENGAGED.get(zone) == level;
                if (!wasEngaged && NpcTracker.get(level.dimension().location()).isEmpty()) continue;

                SuspectChecker.Session s = sessions.computeIfAbsent(level, SuspectChecker.Session::new);
                boolean alive = SuspectChecker.hasAliveSuspect(level, zone, null, s);
                if (alive) {
                    ENGAGED.put(zone, level);
                } else if (wasEngaged) {
                    if (ZoneConfig.DEBUG.get()) {
                        LOGGER.info("[ZoneTaskManager] 兜底扫描区域「{}」：已无存活嫌疑人，触发撤离", zone.name);
                    }
                    clear();
                    EvacuationManager.start(server, zone);
                    return;
                }
            }
        }
    }

    private static boolean isZoneLoaded(ServerLevel level, Zone zone) {
        int cx = (zone.minX + zone.maxX) >> 1;
        int cy = (zone.minY + zone.maxY) >> 1;
        int cz = (zone.minZ + zone.maxZ) >> 1;
        return level.isLoaded(new BlockPos(cx, cy, cz))
                || level.isLoaded(new BlockPos(zone.minX, zone.minY, zone.minZ))
                || level.isLoaded(new BlockPos(zone.maxX, zone.maxY, zone.maxZ));
    }

    public static void clear() {
        PENDING.clear();
        ENGAGED.clear();
        cooldown = 0;
        fallbackCooldown = FALLBACK_INTERVAL_TICKS;
    }

    private ZoneScanQueue() {}
}
