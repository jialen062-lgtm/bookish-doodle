package com.niejiale.zonetask.task;

import com.mojang.logging.LogUtils;
import com.niejiale.zonetask.ModItems;
import com.niejiale.zonetask.config.ZoneConfig;
import org.slf4j.Logger;
import com.niejiale.zonetask.ZoneTaskMod;
import com.niejiale.zonetask.command.PyCommand;
import com.niejiale.zonetask.network.EvacStatePacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.zone.SelectionManager;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import noppes.npcs.entity.EntityNPCInterface;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 服务端事件：生命周期、死亡监听、玩家同步、拦截划分器的方块交互。 */
@Mod.EventBusSubscriber(modid = ZoneTaskMod.MODID)
public final class TaskEvents {
    private static final Logger LOGGER = LogUtils.getLogger();

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) { ZoneStorage.onServerStart(e.getServer()); }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        ZoneStorage.onServerStop();
        EvacuationManager.reset();
        SelectionManager.clear();
        NpcTracker.clear();
        ZoneScanQueue.clear();
        SuspectChecker.clear();
    }

    // ---------- NPC 登记（供区域扫描使用） ----------
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (e.getEntity() instanceof EntityNPCInterface npc) NpcTracker.add(e.getLevel().dimension().location(), npc);
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (e.getEntity() instanceof EntityNPCInterface npc) NpcTracker.remove(e.getLevel().dimension().location(), npc);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) ZoneScanQueue.onServerTick();
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) { PyCommand.register(e.getDispatcher()); }

    /**
     * 监听 LivingDeathEvent：
     *  - 仅服务端处理；LOWEST 且不接收已取消事件，避免统计到被其他模组/脚本取消的“假死亡”
     *  - 死者必须是 CNPC 的 NPC 且阵营为 Aggressive（SuspectChecker）
     *  - 找到包含死者位置的区域，重新扫描该区域存活嫌疑人，归零则进入阶段二
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDeath(LivingDeathEvent e) {
        try {
            LivingEntity dead = e.getEntity();
            // 1) 最便宜的过滤放最前：非 CNPC 的 NPC（所有原版生物）直接返回
            if (!(dead instanceof EntityNPCInterface npc)) return;
            if (!(dead.level() instanceof ServerLevel level) || level.isClientSide) return;
            boolean debug = ZoneConfig.DEBUG.get();
            // 2) 已经在撤离阶段就不用再扫描
            if (EvacuationManager.isActive()) {
                if (debug) LOGGER.info("[ZoneTaskManager] NPC死亡但撤离阶段已在进行，忽略: {}", SuspectChecker.describe(npc));
                return;
            }
            // 3) 先看死亡位置落在哪些区域（纯坐标比较），没有区域就不必查阵营
            Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
            List<Zone> hit = null;
            for (Zone z : zones.values()) {
                if (z.containsEntity(dead)) { if (hit == null) hit = new ArrayList<>(2); hit.add(z); }
            }
            if (hit == null) {
                if (debug) LOGGER.info("[ZoneTaskManager] NPC死亡但不在任何已保存区域内（当前维度共 {} 个区域）: {}", zones.size(), SuspectChecker.describe(npc));
                return;
            }
            // 4) 最后才查阵营
            if (!SuspectChecker.isSuspect(dead, level)) {
                if (debug) LOGGER.info("[ZoneTaskManager] NPC死亡在区域内，但阵营不是 Aggressive，不计入: {}", SuspectChecker.describe(npc));
                return;
            }
            // 5) 不立刻扫描：标记后由 ZoneScanQueue 在几个 tick 后合并扫描一次
            for (Zone zone : hit) {
                if (debug) LOGGER.info("[ZoneTaskManager] 嫌疑人死亡，标记区域「{}」待扫描: {}", zone.name, SuspectChecker.describe(npc));
                ZoneScanQueue.mark(level, zone);
            }
        } catch (Throwable t) {
            // 防御：单个 NPC 判定失败不能拖崩服务端
            System.err.println("[ZoneTaskManager] onLivingDeath 处理失败（已忽略）: " + t);
        }
    }

    // ---------- 玩家同步 ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ZoneNetwork.syncZones(p);
        SelectionManager.send(p);
        ZoneNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new EvacStatePacket(EvacuationManager.isActive()));
    }

    @SubscribeEvent
    public static void onChangeDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        SelectionManager.remove(p.getUUID());
        EvacuationManager.onLogout(p);
    }

    // ---------- 服务端兜底：手持划分器时不允许破坏/放置/交互方块 ----------
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private TaskEvents() {}
}
