package com.niejiale.zonetask.network;

import com.niejiale.zonetask.client.ClientPacketHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.function.Supplier;

/** S2C：当前选点 A/B（可为空）。 */
public record SyncSelectionPacket(ResourceLocation dim, @Nullable BlockPos a, @Nullable BlockPos b) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeResourceLocation(dim);
        buf.writeBoolean(a != null); if (a != null) buf.writeBlockPos(a);
        buf.writeBoolean(b != null); if (b != null) buf.writeBlockPos(b);
    }

    public static SyncSelectionPacket decode(FriendlyByteBuf buf) {
        ResourceLocation dim = buf.readResourceLocation();
        BlockPos a = buf.readBoolean() ? buf.readBlockPos() : null;
        BlockPos b = buf.readBoolean() ? buf.readBlockPos() : null;
        return new SyncSelectionPacket(dim, a, b);
    }

    public static void handle(SyncSelectionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onSelection(msg)));
        ctx.get().setPacketHandled(true);
    }
}
