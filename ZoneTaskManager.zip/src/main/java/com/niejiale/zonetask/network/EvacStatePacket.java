package com.niejiale.zonetask.network;

import com.niejiale.zonetask.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** S2C：撤离阶段是否开启（客户端据此决定按 P 是否发包）。 */
public record EvacStatePacket(boolean active) {
    public void encode(FriendlyByteBuf buf) { buf.writeBoolean(active); }
    public static EvacStatePacket decode(FriendlyByteBuf buf) { return new EvacStatePacket(buf.readBoolean()); }

    public static void handle(EvacStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onEvac(msg)));
        ctx.get().setPacketHandled(true);
    }
}
