package com.niejiale.zonetask.task;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 纯反射桥接 CustomNPCs (CNPC)：
 * - 无需编译期桩类，避免不同 CNPC 构建版本间方法/字段签名微小差异导致 NoSuchMethodError
 * - 仅在首次遇到 CNPC 实体时解析并缓存反射句柄
 */
public final class CnpcBridge {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static volatile boolean initialized = false;
    private static Class<?> npcClass;
    private static Method getFactionMethod;
    private static Field factionField;

    private static Field factionIdField;
    private static Method factionIdMethod;
    private static Field defaultPointsField;
    private static Field neutralPointsField;
    private static Method isAggressiveToPlayerMethod;

    private static Method playerDataGetMethod;
    private static Field factionDataField;
    private static Method getFactionPointsMethod;

    private static boolean warnedError = false;

    private static void init() {
        if (initialized) return;
        synchronized (CnpcBridge.class) {
            if (initialized) return;
            try {
                npcClass = Class.forName("noppes.npcs.entity.EntityNPCInterface");
                try {
                    getFactionMethod = npcClass.getMethod("getFaction");
                } catch (NoSuchMethodException ignored) {
                    factionField = findField(npcClass, "faction");
                }

                Class<?> factionClass = Class.forName("noppes.npcs.controllers.data.Faction");
                factionIdField = findField(factionClass, "id");
                if (factionIdField == null) {
                    try { factionIdMethod = factionClass.getMethod("getId"); } catch (NoSuchMethodException ignored) {}
                }
                defaultPointsField = findField(factionClass, "defaultPoints");
                neutralPointsField = findField(factionClass, "neutralPoints");
                try {
                    isAggressiveToPlayerMethod = factionClass.getMethod("isAggressiveToPlayer", Player.class);
                } catch (NoSuchMethodException ignored) {}

                try {
                    Class<?> playerDataClass = Class.forName("noppes.npcs.controllers.data.PlayerData");
                    playerDataGetMethod = playerDataClass.getMethod("get", Player.class);
                    factionDataField = findField(playerDataClass, "factionData");
                    Class<?> playerFactionDataClass = Class.forName("noppes.npcs.controllers.data.PlayerFactionData");
                    getFactionPointsMethod = playerFactionDataClass.getMethod("getFactionPoints", Player.class, int.class);
                } catch (Throwable t) {
                    LOGGER.warn("[ZoneTaskManager] 未能解析 PlayerData/PlayerFactionData，将回退到 Faction 判定: {}", t.toString());
                }
            } catch (Throwable t) {
                LOGGER.error("[ZoneTaskManager] 初始化 CNPC 反射桥接失败（请确认已安装 CustomNPCs）", t);
            } finally {
                initialized = true;
            }
        }
    }

    private static Field findField(Class<?> cls, String name) {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {}
        }
        return null;
    }

    public static boolean isCnpcNpc(Entity entity) {
        init();
        return npcClass != null && npcClass.isInstance(entity);
    }

    public static boolean isAliveNpc(LivingEntity npc) {
        return npc.isAlive() && !npc.isDeadOrDying() && npc.getHealth() > 0.0F;
    }

    /** 本次扫描共享的阵营敌对缓存 */
    public static final class ScanSession {
        public final List<ServerPlayer> players;
        public final Map<Integer, Boolean> factionHostileCache = new HashMap<>();
        public String lastBlocker = null;

        public ScanSession(List<ServerPlayer> players) {
            this.players = players;
        }
    }

    public static boolean isHostile(LivingEntity npc, ScanSession session) {
        init();
        if (!isCnpcNpc(npc)) return false;
        try {
            Object faction = getFaction(npc);
            if (faction == null) return false;

            int factionId = getFactionId(faction);
            Boolean cached = session.factionHostileCache.get(factionId);
            if (cached != null) return cached;

            boolean hostile = computeFactionHostile(faction, factionId, session.players);
            session.factionHostileCache.put(factionId, hostile);
            return hostile;
        } catch (Throwable t) {
            warnOnce(t);
            return false;
        }
    }

    private static Object getFaction(LivingEntity npc) throws Exception {
        if (getFactionMethod != null) return getFactionMethod.invoke(npc);
        if (factionField != null) return factionField.get(npc);
        return null;
    }

    private static int getFactionId(Object faction) throws Exception {
        if (factionIdField != null) return factionIdField.getInt(faction);
        if (factionIdMethod != null) return ((Number) factionIdMethod.invoke(faction)).intValue();
        return System.identityHashCode(faction);
    }

    private static boolean computeFactionHostile(Object faction, int factionId, List<ServerPlayer> players) throws Exception {
        if (defaultPointsField != null && neutralPointsField != null) {
            int def = defaultPointsField.getInt(faction);
            int neu = neutralPointsField.getInt(faction);
            if (def < neu) return true;

            if (playerDataGetMethod != null && factionDataField != null && getFactionPointsMethod != null) {
                for (ServerPlayer sp : players) {
                    Object pdata = playerDataGetMethod.invoke(null, sp);
                    if (pdata == null) continue;
                    Object fdata = factionDataField.get(pdata);
                    if (fdata == null) continue;
                    int pts = ((Number) getFactionPointsMethod.invoke(fdata, sp, factionId)).intValue();
                    if (pts < neu) return true;
                }
                return false;
            }
        }

        if (isAggressiveToPlayerMethod != null) {
            for (ServerPlayer sp : players) {
                if ((Boolean) isAggressiveToPlayerMethod.invoke(faction, sp)) return true;
            }
        }
        return false;
    }

    public static String describe(LivingEntity npc) {
        String factionInfo = "未知";
        try {
            init();
            Object f = getFaction(npc);
            factionInfo = f == null ? "无" : String.valueOf(getFactionId(f));
        } catch (Throwable ignored) {}
        return npc.getName().getString()
                + " @ " + (int) npc.getX() + "," + (int) npc.getY() + "," + (int) npc.getZ()
                + " [hp=" + String.format("%.1f", npc.getHealth()) + ", alive=" + isAliveNpc(npc)
                + ", 阵营id=" + factionInfo + "]";
    }

    private static void warnOnce(Throwable t) {
        if (!warnedError) {
            warnedError = true;
            LOGGER.error("[ZoneTaskManager] CNPC 阵营判定异常（仅记录一次完整堆栈）", t);
        }
    }

    private CnpcBridge() {}
}
