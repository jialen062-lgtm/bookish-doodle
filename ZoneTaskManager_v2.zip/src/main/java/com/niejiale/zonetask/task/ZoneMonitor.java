package com.niejiale.zonetask.task;

import com.mojang.logging.LogUtils;
import com.niejiale.zonetask.config.ZoneConfig;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import org.slf4j.Logger;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 区域监控器（直接基于 Level 空间实体查询，不依赖易脱节的全局追踪列表）：
 * 1. 状态机：IDLE -> ENGAGED（区域内观测到至少 1 个存活敌对 CNPC，或有敌对 CNPC 死在区域内）
 * 2. 即时触发：CNPC 死亡/销毁离开时标记区域，3 tick 后立即复查
 * 3. 周期兜底：每 10 tick (0.5 秒) 扫描已加载区块内的区域，确保击退边界外死亡、走出区域或被其他模组拦截死亡事件时也能触发撤离
 */
public final class ZoneMonitor {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int EVENT_DELAY_TICKS = 3;
    private static final int POLL_INTERVAL_TICKS = 10;

    private static final Map<Zone, ServerLevel> PENDING = new LinkedHashMap<>();
    private static final Map<Zone, ServerLevel> ENGAGED = new IdentityHashMap<>();
    private static int eventCooldown = 0;
    private static int pollCooldown = POLL_INTERVAL_TICKS;

    public static void markDeath(ServerLevel level, Zone zone) {
        if (PENDING.isEmpty()) eventCooldown = EVENT_DELAY_TICKS;
        PENDING.put(zone, level);
        ENGAGED.put(zone, level);
    }

    public static void markEngagedInDimension(ServerLevel level) {
        for (Map.Entry<Zone, ServerLevel> en : ENGAGED.entrySet()) {
            if (en.getValue() == level) {
                markDeath(level, en.getKey());
            }
        }
    }

    public static void unengageIfUnloaded(ServerLevel level, LivingEntity npc) {
        ENGAGED.entrySet().removeIf(en -> en.getValue() == level && en.getKey().containsEntity(npc));
    }

    public static boolean isEngaged(Zone zone, ServerLevel level) {
        return ENGAGED.get(zone) == level;
    }

    /** 供 /py list 查询当前区域内实时存活敌对 NPC 数量 */
    public static int countAliveHostiles(ServerLevel level, Zone zone, CnpcBridge.ScanSession session) {
        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class, zone.searchAABB(), CnpcBridge::isCnpcNpc);
        int count = 0;
        for (LivingEntity npc : candidates) {
            if (!CnpcBridge.isAliveNpc(npc) || !zone.containsEntity(npc)) continue;
            if (CnpcBridge.isHostile(npc, session)) {
                if (session.lastBlocker == null) session.lastBlocker = CnpcBridge.describe(npc);
                count++;
            }
        }
        return count;
    }

    private static boolean hasAliveHostile(ServerLevel level, Zone zone, CnpcBridge.ScanSession session) {
        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class, zone.searchAABB(), CnpcBridge::isCnpcNpc);
        for (LivingEntity npc : candidates) {
            if (!CnpcBridge.isAliveNpc(npc) || !zone.containsEntity(npc)) continue;
            if (CnpcBridge.isHostile(npc, session)) {
                session.lastBlocker = CnpcBridge.describe(npc);
                return true;
            }
        }
        return false;
    }

    public static void onServerTick(MinecraftServer server) {
        if (EvacuationManager.isActive()) {
            clear();
            return;
        }
        if (server == null) return;

        List<ServerPlayer> players = server.getPlayerList().getPlayers();

        // 1) 死亡事件触发的快速扫描（3 tick 后执行）
        if (!PENDING.isEmpty() && --eventCooldown <= 0) {
            Map<Zone, ServerLevel> batch = new LinkedHashMap<>(PENDING);
            PENDING.clear();
            CnpcBridge.ScanSession session = new CnpcBridge.ScanSession(players);
            for (Map.Entry<Zone, ServerLevel> en : batch.entrySet()) {
                Zone zone = en.getKey();
                ServerLevel level = en.getValue();
                if (ZoneStorage.zones(level.dimension().location()).get(zone.name) != zone) {
                    ENGAGED.remove(zone);
                    continue;
                }
                session.lastBlocker = null;
                boolean alive = hasAliveHostile(level, zone, session);
                if (ZoneConfig.DEBUG.get()) {
                    LOGGER.info("[ZoneTaskManager] 扫描区域「{}」：{}", zone.name,
                            alive ? "仍有存活敌对 NPC -> " + session.lastBlocker : "已无存活敌对 NPC，触发撤离");
                }
                if (!alive) {
                    clear();
                    EvacuationManager.start(server, zone);
                    return;
                }
                ENGAGED.put(zone, level);
            }
        }

        // 2) 周期兜底扫描（每 0.5 秒一次）
        if (--pollCooldown > 0) return;
        pollCooldown = POLL_INTERVAL_TICKS;
        if (players.isEmpty()) return;

        Set<ServerLevel> activeLevels = new LinkedHashSet<>();
        for (ServerPlayer sp : players) activeLevels.add(sp.serverLevel());

        ENGAGED.entrySet().removeIf(en ->
                ZoneStorage.zones(en.getValue().dimension().location()).get(en.getKey().name) != en.getKey());

        CnpcBridge.ScanSession session = new CnpcBridge.ScanSession(players);
        for (ServerLevel level : activeLevels) {
            Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
            if (zones.isEmpty()) continue;
            for (Zone zone : zones.values()) {
                if (!isZoneLoaded(level, zone)) continue;
                boolean wasEngaged = ENGAGED.get(zone) == level;
                session.lastBlocker = null;
                boolean alive = hasAliveHostile(level, zone, session);
                if (alive) {
                    if (!wasEngaged && ZoneConfig.DEBUG.get()) {
                        LOGGER.info("[ZoneTaskManager] 区域「{}」进入交战监控：发现敌对 NPC -> {}", zone.name, session.lastBlocker);
                    }
                    ENGAGED.put(zone, level);
                } else if (wasEngaged) {
                    if (ZoneConfig.DEBUG.get()) {
                        LOGGER.info("[ZoneTaskManager] 兜底扫描区域「{}」：已无存活敌对 NPC，触发撤离", zone.name);
                    }
                    clear();
                    EvacuationManager.start(server, zone);
                    return;
                }
            }
        }
    }

    private static boolean isZoneLoaded(ServerLevel level, Zone zone) {
        int cx = (zone.minX + zone.maxX) >> 1;
        int cy = (zone.minY + zone.maxY) >> 1;
        int cz = (zone.minZ + zone.maxZ) >> 1;
        return level.isLoaded(new BlockPos(cx, cy, cz))
                || level.isLoaded(new BlockPos(zone.minX, zone.minY, zone.minZ))
                || level.isLoaded(new BlockPos(zone.maxX, zone.maxY, zone.maxZ));
    }

    public static void clear() {
        PENDING.clear();
        ENGAGED.clear();
        eventCooldown = 0;
        pollCooldown = POLL_INTERVAL_TICKS;
    }

    private ZoneMonitor() {}
}
