package com.niejiale.zonetask.task;

import com.mojang.logging.LogUtils;
import com.niejiale.zonetask.ModItems;
import com.niejiale.zonetask.ZoneTaskMod;
import com.niejiale.zonetask.command.PyCommand;
import com.niejiale.zonetask.config.ZoneConfig;
import com.niejiale.zonetask.network.EvacStatePacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.zone.SelectionManager;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 服务端事件：生命周期、CNPC 死亡/离开监听、玩家同步、拦截划分器的方块交互。 */
@Mod.EventBusSubscriber(modid = ZoneTaskMod.MODID)
public final class TaskEvents {
    private static final Logger LOGGER = LogUtils.getLogger();

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) { ZoneStorage.onServerStart(e.getServer()); }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        ZoneStorage.onServerStop();
        EvacuationManager.reset();
        SelectionManager.clear();
        ZoneMonitor.clear();
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveLevelEvent e) {
        try {
            if (e.getLevel().isClientSide()) return;
            if (!(e.getEntity() instanceof LivingEntity living) || !CnpcBridge.isCnpcNpc(living)) return;
            if (!(e.getLevel() instanceof ServerLevel level)) return;

            if (!CnpcBridge.isAliveNpc(living)) {
                if (!EvacuationManager.isActive()) {
                    Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
                    boolean marked = false;
                    for (Zone z : zones.values()) {
                        if (z.containsEntity(living)) {
                            ZoneMonitor.markDeath(level, z);
                            marked = true;
                        }
                    }
                    if (!marked) ZoneMonitor.markEngagedInDimension(level);
                }
            } else {
                // 仍存活却离开世界（如区块卸载），取消该区域的交战监控以免误触发撤离
                ZoneMonitor.unengageIfUnloaded(level, living);
            }
        } catch (Throwable t) {
            LOGGER.error("[ZoneTaskManager] onEntityLeave 处理失败（已忽略）", t);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        try {
            ZoneMonitor.onServerTick(e.getServer());
        } catch (Throwable t) {
            LOGGER.error("[ZoneTaskManager] onServerTick 处理失败（已忽略）", t);
        }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) { PyCommand.register(e.getDispatcher()); }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onLivingDeath(LivingDeathEvent e) {
        try {
            LivingEntity dead = e.getEntity();
            if (!CnpcBridge.isCnpcNpc(dead)) return;
            if (!(dead.level() instanceof ServerLevel level) || level.isClientSide) return;

            boolean debug = ZoneConfig.DEBUG.get();
            if (EvacuationManager.isActive()) {
                if (debug) LOGGER.info("[ZoneTaskManager] CNPC 死亡但撤离阶段已在进行，忽略: {}", CnpcBridge.describe(dead));
                return;
            }

            CnpcBridge.ScanSession session = new CnpcBridge.ScanSession(level.getServer().getPlayerList().getPlayers());
            if (!CnpcBridge.isHostile(dead, session)) {
                if (debug) LOGGER.info("[ZoneTaskManager] CNPC 死亡，但非敌对阵营，不计入: {}", CnpcBridge.describe(dead));
                return;
            }

            Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
            List<Zone> hit = null;
            for (Zone z : zones.values()) {
                if (z.containsEntity(dead)) {
                    if (hit == null) hit = new ArrayList<>(2);
                    hit.add(z);
                }
            }

            if (hit == null) {
                ZoneMonitor.markEngagedInDimension(level);
                if (debug) LOGGER.info("[ZoneTaskManager] 敌对 CNPC 死亡但不在区域内（已触发已交战区域复查）: {}", CnpcBridge.describe(dead));
                return;
            }

            for (Zone zone : hit) {
                if (debug) LOGGER.info("[ZoneTaskManager] 敌对 CNPC 死亡，标记区域「{}」待扫描: {}", zone.name, CnpcBridge.describe(dead));
                ZoneMonitor.markDeath(level, zone);
            }
        } catch (Throwable t) {
            LOGGER.error("[ZoneTaskManager] onLivingDeath 处理失败（已忽略）", t);
        }
    }

    // ---------- 玩家同步 ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ZoneNetwork.syncZones(p);
        SelectionManager.send(p);
        ZoneNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new EvacStatePacket(EvacuationManager.isActive()));
    }

    @SubscribeEvent
    public static void onChangeDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        SelectionManager.remove(p.getUUID());
        EvacuationManager.onLogout(p);
    }

    // ---------- 服务端兜底：手持划分器时不允许破坏/放置/交互方块 ----------
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private TaskEvents() {}
}
