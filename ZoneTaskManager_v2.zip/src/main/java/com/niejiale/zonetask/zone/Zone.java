package com.niejiale.zonetask.zone;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 长方体区域（方块坐标，含两端）。字段 public 以便 Gson 直接序列化。 */
public class Zone {
    public String name;
    public int minX, minY, minZ, maxX, maxY, maxZ;
    private transient AABB box;         // 缓存，避免每次 new（transient：不写入 JSON）
    private transient AABB searchBox;   // 包含脚下格与顶部站立余量的实体查询盒

    public Zone() {}

    public Zone(String name, BlockPos a, BlockPos b) {
        this.name = name;
        minX = Math.min(a.getX(), b.getX()); maxX = Math.max(a.getX(), b.getX());
        minY = Math.min(a.getY(), b.getY()); maxY = Math.max(a.getY(), b.getY());
        minZ = Math.min(a.getZ(), b.getZ()); maxZ = Math.max(a.getZ(), b.getZ());
    }

    public AABB aabb() {
        if (box == null) box = new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
        return box;
    }

    public AABB searchAABB() {
        if (searchBox == null) searchBox = new AABB(minX, minY, minZ, maxX + 1, maxY + 2, maxZ + 1);
        return searchBox;
    }

    public boolean contains(Vec3 pos) {
        return aabb().contains(pos);
    }

    /**
     * 实体是否在区域内：按脚下方块坐标判断（含边界），并且把“脚下那一格”也算进去。
     */
    public boolean containsEntity(Entity e) {
        int bx = Mth.floor(e.getX());
        int by = Mth.floor(e.getY());
        int bz = Mth.floor(e.getZ());
        if (bx < minX || bx > maxX || bz < minZ || bz > maxZ) return false;
        return (by >= minY && by <= maxY) || (by - 1 >= minY && by - 1 <= maxY);
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeUtf(name);
        buf.writeInt(minX); buf.writeInt(minY); buf.writeInt(minZ);
        buf.writeInt(maxX); buf.writeInt(maxY); buf.writeInt(maxZ);
    }

    public static Zone read(FriendlyByteBuf buf) {
        Zone z = new Zone();
        z.name = buf.readUtf();
        z.minX = buf.readInt(); z.minY = buf.readInt(); z.minZ = buf.readInt();
        z.maxX = buf.readInt(); z.maxY = buf.readInt(); z.maxZ = buf.readInt();
        return z;
    }
}
