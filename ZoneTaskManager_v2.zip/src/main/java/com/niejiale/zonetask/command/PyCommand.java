package com.niejiale.zonetask.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.task.CnpcBridge;
import com.niejiale.zonetask.task.EvacuationManager;
import com.niejiale.zonetask.task.ZoneMonitor;
import com.niejiale.zonetask.zone.SelectionManager;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

/**
 * /py <名字>      保存当前选区为任务区域
 * /py sc <名字>   删除区域
 * /py list        查看当前维度所有区域与实时敌对 CNPC 数量
 * /py reset       重置撤离状态
 */
public final class PyCommand {
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("py")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("list").executes(PyCommand::list))
                .then(Commands.literal("reset").executes(PyCommand::reset))
                .then(Commands.literal("sc")
                        .then(Commands.argument("name", StringArgumentType.greedyString())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                        ZoneStorage.zones(dim(c.getSource())).keySet(), b))
                                .executes(PyCommand::delete)))
                .then(Commands.argument("name", StringArgumentType.greedyString())
                        .executes(PyCommand::save)));
    }

    private static ResourceLocation dim(CommandSourceStack s) {
        return s.getLevel().dimension().location();
    }

    private static int list(CommandContext<CommandSourceStack> c) {
        CommandSourceStack src = c.getSource();
        ServerLevel level = src.getLevel();
        Map<String, Zone> zones = ZoneStorage.zones(level.dimension().location());
        if (zones.isEmpty()) {
            src.sendSuccess(() -> Component.literal("当前维度没有已保存的任务区域").withStyle(ChatFormatting.YELLOW), false);
            return 1;
        }
        CnpcBridge.ScanSession session = new CnpcBridge.ScanSession(src.getServer().getPlayerList().getPlayers());
        src.sendSuccess(() -> Component.literal("当前维度任务区域（撤离阶段: "
                + (EvacuationManager.isActive() ? "进行中" : "未开启") + "）：").withStyle(ChatFormatting.AQUA), false);
        for (Zone z : zones.values()) {
            session.lastBlocker = null;
            int alive = ZoneMonitor.countAliveHostiles(level, z, session);
            boolean engaged = ZoneMonitor.isEngaged(z, level);
            String info = String.format(" - 「%s」 [%d,%d,%d ~ %d,%d,%d] 状态=%s 存活敌对=%d",
                    z.name, z.minX, z.minY, z.minZ, z.maxX, z.maxY, z.maxZ,
                    engaged ? "监控中" : "待机", alive);
            src.sendSuccess(() -> Component.literal(info), false);
        }
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> c) {
        EvacuationManager.forceReset(c.getSource().getServer());
        return 1;
    }

    private static int save(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        CommandSourceStack src = c.getSource();
        ServerPlayer p = src.getPlayerOrException();
        String name = StringArgumentType.getString(c, "name").trim();
        if (name.isEmpty() || name.length() > 32) {
            src.sendFailure(Component.literal("区域名称长度需为 1~32 个字符"));
            return 0;
        }
        SelectionManager.Sel sel = SelectionManager.get(p.getUUID());
        ResourceLocation dim = dim(src);
        if (sel == null || sel.a == null || sel.b == null || !sel.dim.equals(dim)) {
            src.sendFailure(Component.literal("请先用「地图区域划分器」在当前维度选好点 A（左键）和点 B（右键）"));
            return 0;
        }
        boolean existed = ZoneStorage.zones(dim).containsKey(name);
        ZoneStorage.put(dim, new Zone(name, sel.a, sel.b));
        ZoneNetwork.broadcastZones(src.getServer(), dim);
        src.sendSuccess(() -> Component.literal((existed ? "已更新任务区域: " : "已保存任务区域: ") + name)
                .withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    private static int delete(CommandContext<CommandSourceStack> c) {
        CommandSourceStack src = c.getSource();
        String name = StringArgumentType.getString(c, "name").trim();
        ResourceLocation dim = dim(src);
        if (!ZoneStorage.remove(dim, name)) {
            src.sendFailure(Component.literal("当前维度不存在区域: " + name));
            return 0;
        }
        ZoneNetwork.broadcastZones(src.getServer(), dim);
        src.sendSuccess(() -> Component.literal("已删除任务区域: " + name).withStyle(ChatFormatting.YELLOW), true);
        return 1;
    }

    private PyCommand() {}
}
