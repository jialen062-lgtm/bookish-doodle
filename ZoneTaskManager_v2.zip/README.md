# 区域任务管理器 (zonetaskmanager) v2.0.0

Minecraft 1.20.1 / Forge 47.3.0 / 依赖 CustomNPCs (`customnpcs`)

## 核心特性
1. **区域划分与可视化**：手持「地图区域划分器」左键设 A 点、右键设 B 点，实时预览线框；`/py <名称>` 保存区域，`/py sc <名称>` 删除，`/py list` 查看区域状态与存活敌对数，`/py reset` 重置撤离状态。
2. **纯反射 CNPC 桥接 (`CnpcBridge`)**：无需编译期桩类，直接兼容不同 CustomNPCs 1.20.1 构建版本。判定标准：阵营默认点数 `< 中立阈值`，或任意在线玩家对该阵营声望 `< 中立阈值`。
3. **直接空间查询 + 状态机 (`ZoneMonitor`)**：直接通过 `ServerLevel.getEntitiesOfClass` 查询区域内 CNPC 实体，配合死亡/销毁事件快速复查（3 tick）与每 0.5 秒周期兜底扫描，解决击退至边界外、死亡事件被拦截或实体列表脱节导致的漏触发问题。
4. **全员投票撤离与结算 (`EvacuationManager`)**：清剿后广播提示按 `P` 键准备撤离；全员准备后传送至 `config/zonetaskmanager-common.toml` 配置坐标并执行 `postEvacuationCommand`（默认 `taczcnpc respawn`）。

## 构建
直接导入 Gradle 项目并运行 `./gradlew build`，产物位于 `build/libs/`。
